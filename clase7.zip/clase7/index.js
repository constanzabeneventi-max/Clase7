const express = require('express')
const app = express()

const webSocket = require('express-ws')
webSocket(app)

app.use(express.static('public'))

const paath = require('path')

app.listen(8000, () =>{
    console.log('Aplicación corriendo en puerto 8000')
})

app.get('/',(req, res) => {
    res.sendFile(path.join(_dirname, 'public/index.html'))
})

app.ws('/', handleWs)

function handleWs(ws){
    console.log('Nuevo web socket.')

    ws.on('message', (m) =>{
        console.log(m)
    })
}